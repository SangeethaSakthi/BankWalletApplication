package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.beans.Transaction;
import com.cg.beans.WalletHolder;
import com.cg.db.DBUtil;
import com.cg.exception.WalletException;

public class WalletDao implements IWalletDao {

	
	Connection con;
	WalletHolder loginHolder, transferHolder;
	public WalletDao() throws WalletException {
		con = DBUtil.getConnect();
		 loginHolder = new WalletHolder();
		 transferHolder = new WalletHolder();
	}
	public int addWallet(WalletHolder holder) {

		int row = 0;
		try{

			String sql = "INSERT INTO Wallet(pinNo, name, password, accountNo, email , phNo, balance) VALUES(?,?,?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, holder.getPinNo());
			pstmt.setString(2, holder.getName());
			pstmt.setString(3, holder.getPassword());
			pstmt.setString(4, holder.getAccountNo());
			pstmt.setString(5, holder.getEmail());
			pstmt.setString(6, holder.getPhno());
			pstmt.setDouble(7, holder.getBalance());
			
			row = pstmt.executeUpdate();
			if(row>0)
			{
				return row;
			}
			
		}
		catch(Exception e)
		{
			System.out.println("exception");
			System.out.println(e.getMessage());
		}
		return row;
	}
	public int generatePinNo(WalletHolder holder) {
		double pin = Math.random()*10000;
		int pinNo = (int)pin;
		holder.setPinNo(pinNo);
		return pinNo;
	}
	public WalletHolder checkLoginDetails(String name, String password) {
		try
		{
			String sql = "Select * from Wallet where name =? AND password = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);	
			pstmt. setString(1, name);
			pstmt.setString(2, password);
			ResultSet res = pstmt.executeQuery();
			if(res.next())
			{
				loginHolder.setPinNo(res.getInt(1));
				loginHolder.setName(res.getString(2));
				loginHolder.setPassword(res.getString(3));
				loginHolder.setAccountNo(res.getString(4));
				loginHolder.setEmail(res.getString(5));
				loginHolder.setPhno(res.getString(6));
				loginHolder.setBalance(res.getDouble(7));
				
			}
			
		}
		catch(Exception e)
		{
			e.getMessage();
		
		}
		
		return loginHolder;
	}
	public double withdraw(int pinNo, double balance) {
		double flag = 0;
		try
		{
			if(loginHolder.getPinNo()==pinNo && loginHolder.getBalance()>=balance)
			{
				loginHolder.setBalance(loginHolder.getBalance()-balance);
				String sql = "Update Wallet Set balance = ? Where pinNo=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setDouble(1, loginHolder.getBalance());
				pstmt.setInt(2, pinNo);
				int row = pstmt.executeUpdate();
				if(row>0)
					{flag=loginHolder.getBalance();
				String sql1 = "Insert into Transaction (userName, accountNo, description, transactionAccNo, deposit, withdrawal, balance, pinNoF) values"
						+ "(?,?,?,?,?,?,?,?)";
				PreparedStatement pstmt1 = con.prepareStatement(sql1);	
				pstmt1. setString(1, loginHolder.getName());
				pstmt1.setString(2,loginHolder.getAccountNo());
				pstmt1.setString(3, "Withdrawal");
				pstmt1.setString(4, "------");
				pstmt1.setDouble(5, 0);			
				pstmt1.setDouble(6, balance);
				pstmt1.setDouble(7,loginHolder.getBalance());
				pstmt1.setInt(8,loginHolder.getPinNo());
				int r = pstmt1.executeUpdate();
							
			}
		} 
		}
		catch (SQLException e) 
		{
			e.getMessage();
		}
		return flag;
	}
	public double deposit(int pinNo, double balance) {
		double flag= 0;
		try
		{
			if(loginHolder.getPinNo()==pinNo)
			{
				loginHolder.setBalance(loginHolder.getBalance()+balance);
				String sql = "Update Wallet Set balance = ? Where pinNo=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setDouble(1, loginHolder.getBalance());
				pstmt.setInt(2, pinNo);
				int row = pstmt.executeUpdate();
				if(row>0)
					flag=loginHolder.getBalance();
				String sql1 = "Insert into Transaction (userName, accountNo, description, transactionAccNo, deposit, withdrawal, balance, pinNoF) values"
						+ "(?,?,?,?,?,?,?,?)";
				PreparedStatement pstmt1 = con.prepareStatement(sql1);	
				pstmt1. setString(1, loginHolder.getName());
				pstmt1.setString(2,loginHolder.getAccountNo());
				pstmt1.setString(3, "Deposit");
				pstmt1.setString(4, "------");
				pstmt1.setDouble(5, balance);			
				pstmt1.setDouble(6, 0);
				pstmt1.setDouble(7,loginHolder.getBalance());
				pstmt1.setInt(8,loginHolder.getPinNo());
				int r = pstmt1.executeUpdate();
			}
		} 
		catch (SQLException e) 
		{
			e.getMessage();
		}
		
		return flag;
	}
	public boolean nameExists(String name) {
		boolean flag=false;
		try
		{
			String sql = "Select * from Wallet where name=?";
			PreparedStatement pstmt = con.prepareStatement(sql);	
			pstmt. setString(1, name);
			ResultSet res = pstmt.executeQuery();
			if(res.next())
				flag = true;
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		
		return flag;
	}
	public double moneyTransfer(int pinNo, String uname, double balance) {
		double flag =0;
		try
		{
			if(loginHolder.getPinNo()==pinNo )
			{
				String sql = "Select * from Wallet where name=?";
				PreparedStatement pstmt = con.prepareStatement(sql);	
				pstmt. setString(1, uname);
				ResultSet res = pstmt.executeQuery();
				if(res.next())
				{
					transferHolder.setPinNo(res.getInt(1));
					transferHolder.setName(res.getString(2));
					transferHolder.setPassword(res.getString(3));
					transferHolder.setAccountNo(res.getString(4));
					transferHolder.setEmail(res.getString(5));
					transferHolder.setPhno(res.getString(6));
					transferHolder.setBalance(res.getDouble(7));
					if(withdrawTo(pinNo, balance))
					{
						if(depositTo(uname,balance))
							flag=loginHolder.getBalance();
					}
					
				}
				else
					flag=-1;
			}
			
		} 
		catch (Exception e) 
		{
			e.getMessage();
		}
		return flag;
		
		
	}
	public boolean depositTo(String uname, double balance) {
		boolean flag=false;
		try {
			transferHolder.setBalance(transferHolder.getBalance()+balance);
			String sql = "Insert into Transaction (userName, accountNo, description, transactionAccNo, deposit, withdrawal, balance, pinNoF) values"
					+ "(?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt1 = con.prepareStatement(sql);	
			pstmt1. setString(1, loginHolder.getName());
			pstmt1.setString(2,loginHolder.getAccountNo());
			pstmt1.setString(3, "Money Transacted to");
			pstmt1.setString(4, transferHolder.getName());
			pstmt1.setDouble(5, 0);			
			pstmt1.setDouble(6, balance);
			pstmt1.setDouble(7,loginHolder.getBalance());
			pstmt1.setInt(8,loginHolder.getPinNo());
			int r1 = pstmt1.executeUpdate();
			
			PreparedStatement pstmt = con.prepareStatement(sql);	
			pstmt. setString(1, uname);
			pstmt.setString(2,transferHolder.getAccountNo());
			pstmt.setString(3, "Money Transacted from");
			pstmt.setString(4, loginHolder.getName());
			pstmt.setDouble(5, balance);			
			pstmt.setDouble(6, 0);
			pstmt.setDouble(7,transferHolder.getBalance());
			pstmt.setInt(8,transferHolder.getPinNo());
			int r = pstmt.executeUpdate();
						
			if(r>0 && r1>0)
				flag=true;
			
		} 
		catch (Exception e) {
				e.getMessage();
		}
		
		return flag;
	}
	public ArrayList<Transaction> showTransaction(String name) {
		ArrayList<Transaction> l = new ArrayList<Transaction>();
		try
		{
			
			String sql = "Select * from Wallet where name=?";
			PreparedStatement pstmt = con.prepareStatement(sql);	
			pstmt. setString(1, name);
			ResultSet res = pstmt.executeQuery();
			if(res.next())
			{
				

				int pinNo = res.getInt(1);
				String sql1 = "Select * from Transaction where pinNoF=?";
				PreparedStatement pstmt1 = con.prepareStatement(sql1);	
				pstmt1. setInt(1, pinNo);
				ResultSet res1 = pstmt1.executeQuery();
				
				while(res1.next())
				{	
					Transaction t = new Transaction();
					t.setName(res1.getString(1));
					t.setAccountNo(res1.getString(2));
					t.setDescription(res1.getString(3));
					t.setTransactionAccNo(res1.getString(4));
					t.setDeposit(res1.getDouble(5));
					t.setWithdrawal(res1.getDouble(6));
					t.setCurrentBal(res1.getDouble(7));
					t.setPinNo(res1.getInt(8));
					l.add(t);
				}
				
			}
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		
		return l;
	}
	public boolean withdrawTo(int pinNo, double balance) {
		boolean flag = false;
		try
		{
			if(loginHolder.getPinNo()==pinNo && loginHolder.getBalance()>=balance)
			{
				loginHolder.setBalance(loginHolder.getBalance()-balance);
				String sql = "Update Wallet Set balance = ? Where pinNo=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setDouble(1, loginHolder.getBalance());
				pstmt.setInt(2, pinNo);
				int row = pstmt.executeUpdate();
				if(row>0)	
				{
					flag=true;
				}
			}
			
		} 
		catch (Exception e) 
		{
			e.getMessage();
		}
		return flag;
	}
	public double getBalance() {
		return loginHolder.getBalance();
	}
	
}
	