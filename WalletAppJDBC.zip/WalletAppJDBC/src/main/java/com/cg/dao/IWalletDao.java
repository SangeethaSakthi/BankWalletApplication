package com.cg.dao;

import java.util.ArrayList;

import com.cg.beans.Transaction;
import com.cg.beans.WalletHolder;

public interface IWalletDao {

	int addWallet(WalletHolder holder);

	int generatePinNo(WalletHolder holder);
	
	WalletHolder checkLoginDetails(String name, String password);

	double withdraw(int pinNo, double balance);

	double deposit(int pinNo, double balance);

	boolean nameExists(String name);
	
	double moneyTransfer(int pinNo, String uname, double balance);
	
	boolean depositTo(String uname,double balance);
	
	boolean withdrawTo(int pinNo, double balance);

	ArrayList<Transaction> showTransaction(String name);
	
	double getBalance();


}
