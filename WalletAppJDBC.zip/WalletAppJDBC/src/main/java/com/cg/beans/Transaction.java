package com.cg.beans;

public class Transaction {

	private String name;
	private String accountNo;
	private String description;
	private String transactionAccNo;
	private double deposit;
	private double withdrawal;
	private double currentBal;
	private int pinNo;
	public String getName() {
		return name;
	}
	@Override
	public String toString() {
		return "|   "+name+"   |  "+ accountNo+"  |  "+ description+"  |   "+
			transactionAccNo+"   |  "+ deposit +"  |  "+ withdrawal+"  |  "+
				currentBal+"  |";
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTransactionAccNo() {
		return transactionAccNo;
	}
	public void setTransactionAccNo(String transactionAccNo) {
		this.transactionAccNo = transactionAccNo;
	}
	public double getDeposit() {
		return deposit;
	}
	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}
	public double getWithdrawal() {
		return withdrawal;
	}
	public void setWithdrawal(double withdrawal) {
		this.withdrawal = withdrawal;
	}
	public double getCurrentBal() {
		return currentBal;
	}
	public void setCurrentBal(double currentBal) {
		this.currentBal = currentBal;
	}
	public int getPinNo() {
		return pinNo;
	}
	public void setPinNo(int pinNo) {
		this.pinNo = pinNo;
	}
	
}
