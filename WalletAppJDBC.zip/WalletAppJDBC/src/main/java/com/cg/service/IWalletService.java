package com.cg.service;

import java.util.ArrayList;

import com.cg.beans.Transaction;
import com.cg.beans.WalletHolder;

public interface IWalletService {

	int addWallet(WalletHolder holder);

	boolean nameExists(String name);

	boolean validateName(String name);

	boolean validatePassword(String password);

	boolean validateAccNo(String accountNo);

	boolean validateEmail(String email);

	boolean validatePhNo(String phNo);

	int generatePinNo(WalletHolder holder);

	WalletHolder checkLoginDetails(String name, String password);

	double withdraw(int pinNo, double balance);

	double deposit(int pinNo, double balance);
	
	double moneyTransfer(int pinNo, String uname, double balance);

	ArrayList<Transaction> showTransaction(String name);
	
	double getBalance();



}
