package com.capgemini.payment.WalletApplication;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.capgemini.beans.WalletHolder;
import com.capgemini.dao.IUpadatingWallet;
import com.capgemini.dao.UpdatingWallet;
import com.capgemini.exception.WalletException;
import com.capgemini.service.GenerateWallet;
import com.capgemini.service.IGenerateWallet;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
	IUpadatingWallet update = new UpdatingWallet();
	WalletHolder w = new WalletHolder();
   @Test //  test for inserting username which not exists
    public void toTestAddWalletPass() throws WalletException
    {
        w.setName("Onew");
        w.setAccountNo("1234567890");
        w.setEmail("minho@fmail.com");
        w.setPhno("9876545609");
        /*
         * If Username already exits then it will return 0 otherwise it return 1
         */
        assertEquals(1, update.addWallet(w));
    }
    
   @Test //  test for inserting username which exists
    public void toTestAddWalletFail() throws WalletException
    {
        w.setName("Minho");
        w.setAccountNo("1234567890");
        w.setEmail("minho@fmail.com");
        w.setPhno("9876545609");
        int i=update.addWallet(w);
        WalletHolder w2 = new WalletHolder();
        w2.setName("Minho");
        w2.setAccountNo("9786997890");
        w2.setEmail("mio@fmail.com");
        w2.setPhno("2256545609");        
        /*
         * If Username already exits then it will return 0 otherwise it return 1
         */
        assertEquals(0,  update.addWallet(w2));
    }
    
    // test for exception should not throw for existing username if it is accessed
    @Test    
    public void toTestGetWalletPass() throws WalletException
    {
    	
    	w.setName("Minho");
        w.setAccountNo("1234567890");
        w.setEmail("minho@fmail.com");
        w.setPhno("9876545609");
        int i=update.addWallet(w);
    	w = update.getWalletProfile("Minho");
    	assertNotNull(w);
    }
    
    // test for exception should throw for username not existing
    @Test
    public void toTestGetWalletFail() throws WalletException
    {
    	//IUpadatingWallet update = new UpdatingWallet();
    	
    	WalletHolder w2= new WalletHolder();
    	 w2 = update.getWalletProfile("Mkk");
    	assertNull(w2);
    }
    
}
