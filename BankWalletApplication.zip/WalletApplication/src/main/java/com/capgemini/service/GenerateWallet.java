package com.capgemini.service;

import com.capgemini.beans.WalletHolder;
import com.capgemini.dao.UpdatingWallet;
import com.capgemini.exception.WalletException;

public class GenerateWallet implements IGenerateWallet{

	UpdatingWallet newWallet ;
	//private static String pinNoToMatch = "[0-9]{4}";
	private static String nameToMatch = "[A-Z]{1}[a-z]{2,30}";
	private static String passwordToMatch = "[A-Za-z0-9]{4,8}";
	private static String phNoToMatch = "[0-9]{10}";
	private static String accountNoToMatch ="[0-9]{10}";
	private static String emailToMatch = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w]+(\\.[\\w]+)*(\\.[a-z]{2,})$"; 
			//"[a-z0-9]{1,}[@][a-z]{1,}[.][com]";
	
	 public GenerateWallet() {
		// TODO Auto-generated constructor stub
		newWallet = new UpdatingWallet();
	}
	@Override
	public int createNewWallet(WalletHolder w) throws WalletException{
		// TODO Auto-generated method stub
	
		return newWallet.addWallet(w);
		
	}

	@Override
	public boolean  validateName(String name) {
		// TODO Auto-generated method stub
		if(name.matches(nameToMatch))
			return true;
		else
			return false;
		
		
		
		
		/*if(name.matches(nameToMatch))
		{
			if(newWallet.nameExits(name))
				return 0;//string unique 
			else 
				return 1;//string exists 
		}else
		return -1;//string doesnt matches*/
	}
	@Override
	public boolean nameExists(String name) {
		if(newWallet.nameExits(name))
			return true;
		else
			return false;
		
	}

	@Override
	public boolean validatePhNo(String phNo) {
		// TODO Auto-generated method stub
		if(phNo.matches(phNoToMatch))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateAccNo(String accountNo) {
		// TODO Auto-generated method stub
		if(accountNo.matches(accountNoToMatch))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateEmail(String email) {
		// TODO Auto-generated method stub
		if(email.matches(emailToMatch))
			return true;
		else
		return false;
	}

	@Override
	public boolean validatePassword(String password) {
		// TODO Auto-generated method stub
		if(password.matches(passwordToMatch))
			return true;
		else
		return false;
	}

	

	@Override
	public WalletHolder checkLoginDetails(String name, String password) {
		// TODO Auto-generated method stub
		//newWallet.print();
		return newWallet.toCompare(name, password);
	}

	@Override
	public WalletHolder deposit(WalletHolder holder, double amount, int pinNo) {
		// TODO Auto-generated method stub
		if(holder.getPinNo()==pinNo)
		{
			WalletHolder h =newWallet.depositWallet(holder, amount);
			if(h!=null)
				return h;
			else
				return h;
		}
		else
			return null;
		
	}

	@Override
	public WalletHolder withdraw(WalletHolder holder, double amount, int pinNo) {
		// TODO Auto-generated method stub
		if(holder.getPinNo()==pinNo)
		{
			WalletHolder h =newWallet.withdrawWallet(holder, amount);
			if(h!=null)
				return h;
			else
				return h;
		}
		else
			return null;
		
		
	}

	@Override
	public WalletHolder getProfile(String name)throws WalletException {
		// TODO Auto-generated method stub
		return newWallet.getWalletProfile(name);
	}

	

	@Override
	public WalletHolder depositTo(WalletHolder h2, double tamount) {
		// TODO Auto-generated method stub
		 return newWallet.depositWallet(h2, tamount);
	}
	@Override
	public int pinNo(WalletHolder holder) {
		// TODO Auto-generated method stub
		double pinNo1 = Math.random()*100000;
		int pinNo = (int)pinNo1;
		holder.setPinNo(pinNo);
		return pinNo;
	}
	

	
	
	
	
}
