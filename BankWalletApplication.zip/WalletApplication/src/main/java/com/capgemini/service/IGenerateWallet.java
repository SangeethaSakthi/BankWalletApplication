package com.capgemini.service;

import com.capgemini.beans.WalletHolder;
import com.capgemini.exception.WalletException;

public interface IGenerateWallet {

	public int createNewWallet(WalletHolder w) throws WalletException;
	
	public WalletHolder checkLoginDetails(String name, String paswword);
	
	public WalletHolder deposit(WalletHolder holder,double amount, int pinNo);
	
	public WalletHolder withdraw(WalletHolder holder,double amount, int pinNo);
	
	public boolean validateName(String name);
	
	public boolean validatePhNo(String phNo);	
	
	public boolean validateAccNo(String accountNo);
	
	public boolean validateEmail(String email);
	
	public boolean validatePassword(String password);
	
	
	
	public WalletHolder getProfile(String name) throws WalletException ;

	

	public WalletHolder depositTo(WalletHolder h2, double tamount);

	boolean nameExists(String name);

	public int pinNo(WalletHolder holder);

		
	
	
}
