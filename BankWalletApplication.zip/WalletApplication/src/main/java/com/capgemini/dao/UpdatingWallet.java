package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.beans.WalletHolder;
import com.capgemini.exception.WalletException;

public class UpdatingWallet implements IUpadatingWallet{
	
	static HashMap<String, WalletHolder> wallets= new HashMap<String, WalletHolder>();
	
	
	@Override
	public void print()
	{
		for(Map.Entry<String, WalletHolder> entry :wallets.entrySet())
		{
			System.out.println("ke"+entry.getKey()+"\ndfg"+entry.getValue());
		}
	}
		
	@Override
	public int addWallet(WalletHolder w)  throws WalletException{
		// TODO Auto-generated method stub
		
		if(wallets.containsKey(w.getName())){
			//System.out.println("inside");
			return 0;}
		else
			{
			String s = w.getName();
						
			wallets.put(s, (WalletHolder)w);
			return 1;
			}
	}

	@Override
	public WalletHolder getWalletProfile(String name) throws WalletException {
		// TODO Auto-generated method stub
		WalletHolder w=null;
		if(wallets.containsKey(name))
			w= wallets.get(name);
		return w;
	}

	@Override
	public WalletHolder toCompare(String name, String password) {
		// TODO Auto-generated method stub
		//System.out.println("wall2"+name+" pass "+password);
		if(wallets.containsKey(name))
		{
			
			WalletHolder temp = wallets.get(name);
			
			if(temp.getPassword().equals(password)){
				return temp;}
			else
				return null;
		}
		return null;
	}

	@Override
	public boolean nameExits(String name) {
		// TODO Auto-generated method stub
		if(wallets.containsKey(name))
			return true;
		else
			return false;
	}

	@Override
	public WalletHolder depositWallet(WalletHolder w, double amount) {
		// TODO Auto-generated method stub
		if(wallets.containsKey(w.getName()))
		{
			double bal = w.getBalance() + amount;
			w.setBalance(bal);
			wallets.put(w.getName(), w); // deposited
			return w;
		}
		return null; // there is no account for given name
	}

	@Override
	public WalletHolder withdrawWallet(WalletHolder w, double amount) {
		// TODO Auto-generated method stub
		if(wallets.containsKey(w.getName()))
		{
			if(amount<=w.getBalance())
			{
				double bal = w.getBalance() - amount;
				w.setBalance(bal);
				wallets.put(w.getName(), w);
				return w; // withdrawn 
			}
			else
				return null; // not sufficient money to withdraw
			
		}
		return null;
	}
	
	

	
}
