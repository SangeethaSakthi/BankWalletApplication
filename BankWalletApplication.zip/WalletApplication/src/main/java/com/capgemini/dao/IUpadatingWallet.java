package com.capgemini.dao;

import com.capgemini.beans.WalletHolder;
import com.capgemini.exception.WalletException;

public interface IUpadatingWallet {

	public boolean nameExits(String name);
	
	public int addWallet(WalletHolder w) throws WalletException;
	
	public WalletHolder depositWallet(WalletHolder w, double amount);
	
	public WalletHolder withdrawWallet(WalletHolder w, double amount);
	
	public WalletHolder getWalletProfile(String name)throws WalletException;
	
	public WalletHolder toCompare(String name, String password);

	public void print();
	
	
}
