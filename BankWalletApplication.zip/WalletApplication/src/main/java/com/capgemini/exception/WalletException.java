package com.capgemini.exception;

public class WalletException extends Exception {

	String msg;

	public WalletException(String msg) {
		
		this.msg = msg;
	}

	public String getMsg() {
		return msg;
	}

}
