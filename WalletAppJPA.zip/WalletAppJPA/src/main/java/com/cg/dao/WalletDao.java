package com.cg.dao;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.beans.Transaction;
import com.cg.beans.WalletHolder;
import com.cg.exception.WalletException;
import com.cg.util.DBUtil;

public class WalletDao implements IWalletDao {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("hello");
	EntityManager em = factory.createEntityManager();
	
	WalletHolder loginHolder, transferHolder;
	public WalletDao() throws WalletException {
		// em = DBUtil.getEntityManager();
		 loginHolder = new WalletHolder();
		 transferHolder = new WalletHolder();
	}
	@Override
	public int addWallet(WalletHolder holder) {
		em.getTransaction().begin();
		em.persist(holder);
		em.getTransaction().commit();
		return 1;
	}
	@Override
	public int generatePinNo(WalletHolder holder) {
		double pin = Math.random()*10000;
		int pinNo = (int)pin;
		holder.setPinNo(pinNo);
		return pinNo;
	}
	@Override
	public WalletHolder checkLoginDetails(String name, String password)throws WalletException {
		try {
		String sql = "Select w From WalletHolder w Where w.name=:name AND w.password=:password";
		TypedQuery<WalletHolder> query = em.createQuery(sql, WalletHolder.class);
		query.setParameter("name", name);
		query.setParameter("password", password);
		loginHolder = query.getSingleResult();
		return loginHolder;
		}
		catch(Exception e){
			System.out.println(e.getMessage());}
		return null;
	}
	@Override
	public double withdraw(int pinNo, double balance)throws WalletException {
		if(loginHolder.getPinNo()==pinNo && loginHolder.getBalance()>=balance)
		{
			loginHolder.setBalance(loginHolder.getBalance()-balance);
			em.getTransaction().begin();
			em.merge(loginHolder);
			Transaction t = new Transaction();
			t.setUserName(loginHolder.getName());
			t.setAccountNo(loginHolder.getAccountNo());
			t.setDescription("       Withdrawal       ");
			t.setTransactionAccName("        ----        ");
			t.setDeposit(0);
			t.setWithdrawal(balance);
			t.setBalance(loginHolder.getBalance());
			t.setWalletHolder(loginHolder);
			em.persist(t);
			em.getTransaction().commit();
		}
		return loginHolder.getBalance();
	}
	@Override
	public double deposit(int pinNo, double balance) throws WalletException{
		if(loginHolder.getPinNo()==pinNo)
		{
			loginHolder.setBalance(loginHolder.getBalance()+balance);
			em.getTransaction().begin();
			em.merge(loginHolder);
			Transaction t = new Transaction();
			t.setUserName(loginHolder.getName());
			t.setAccountNo(loginHolder.getAccountNo());
			t.setDescription("        Deposited       ");
			t.setTransactionAccName("        ----        ");
			t.setDeposit(balance);
			t.setWithdrawal(0);
			t.setBalance(loginHolder.getBalance());
			t.setWalletHolder(loginHolder);
			em.persist(t);
			em.getTransaction().commit();
		}
		return loginHolder.getBalance();
	}
	@Override
	public boolean nameExists(String name)throws WalletException {
		String sql = "Select w From WalletHolder w Where w.name=:name";
		TypedQuery<WalletHolder> query = em.createQuery(sql, WalletHolder.class);
		query.setParameter("name", name);
		WalletHolder w = query.getSingleResult();
		return w.getName().equals(name);
		
		
	}
	@Override
	public double moneyTransfer(int pinNo, String uname, double balance)throws WalletException {
		if(loginHolder.getPinNo()==pinNo )
		{
			String sql = "Select w From WalletHolder w Where w.name=:name";
			TypedQuery<WalletHolder> query = em.createQuery(sql, WalletHolder.class);
			query.setParameter("name", uname);
			transferHolder = query.getSingleResult();
			if(transferHolder.getName().equals(null))
				return -1;
			else if(transferHolder.getName().equalsIgnoreCase(uname))
			{
				if(withdrawTo(pinNo, balance))
				{
				if(depositTo(uname, balance))
					return loginHolder.getBalance();
				}
			}
			else
				return 0;
		}
		
			return 0;
	}
	@Override
	public boolean depositTo(String uname, double balance)throws WalletException {
		transferHolder.setBalance(transferHolder.getBalance()+balance);
		em.getTransaction().begin();
		em.merge(transferHolder);
		Transaction t = new Transaction();
		t.setUserName(loginHolder.getName());
		t.setAccountNo(loginHolder.getAccountNo());
		t.setDescription("Money transferred to");
		t.setTransactionAccName("    "+transferHolder.getName()+"    ");
		t.setDeposit(0);
		t.setWithdrawal(balance);
		t.setBalance(loginHolder.getBalance());
		t.setWalletHolder(loginHolder);
		em.persist(t);
		Transaction t1 = new Transaction();
		t1.setUserName(transferHolder.getName());
		t1.setAccountNo(transferHolder.getAccountNo());
		t1.setDescription("Money transferred from");
		t1.setTransactionAccName("    "+loginHolder.getName()+"    ");
		t1.setDeposit(balance);
		t1.setWithdrawal(0);
		t1.setBalance(transferHolder.getBalance());
		t1.setWalletHolder(transferHolder);
		em.persist(t1);
		em.getTransaction().commit();
		return true;
	}
	@Override
	public boolean withdrawTo(int pinNo, double balance) {
		if(loginHolder.getPinNo()==pinNo && loginHolder.getBalance()>=balance)
		{
			loginHolder.setBalance(loginHolder.getBalance()-balance);
			em.getTransaction().begin();
			em.merge(loginHolder);
			em.getTransaction().commit();
			return true;
		}
		return false;
	}
	@Override
	public List<Transaction> showTransaction(String name) throws WalletException{
		String sql= "Select t from Transaction t where t.userName=:name";
		TypedQuery< Transaction> query = em.createQuery(sql,Transaction.class);
		query.setParameter("name",loginHolder.getName());
		
		List<Transaction> al = query.getResultList();
		return al;
	}
	@Override
	public double showBalance() throws WalletException{
		return loginHolder.getBalance();
	}
	
}
	
	