package com.cg.beans;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Transaction implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO )
	int id;
	String userName;
	String accountNo;
	String description;
	String transactionAccName;
	double deposit;
	double withdrawal;
	double balance;
	@ManyToOne
	@JoinColumn(name="pinNo")
	WalletHolder walletHolder;
	
	 
	public WalletHolder getWalletHolder() {
		return walletHolder;
	}
	public void setWalletHolder(WalletHolder walletHolder) {
		this.walletHolder = walletHolder;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public String getUserName() {
		return userName;
	}
	@Override
	public String toString() {
		return "|  "+userName+"  |  "+ accountNo+"  |  "+ description+"  |  "+
			transactionAccName+"  |  "+ deposit +"  |  "+ withdrawal+"  |  "+
				balance+"  |";
	}
	public void setUserName(String name) {
		this.userName = name;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTransactionAccName() {
		return transactionAccName;
	}
	public void setTransactionAccName(String transactionAccName) {
		this.transactionAccName = transactionAccName;
	}
	public double getDeposit() {
		return deposit;
	}
	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}
	public double getWithdrawal() {
		return withdrawal;
	}
	public void setWithdrawal(double withdrawal) {
		this.withdrawal = withdrawal;
	}
	
	
}
