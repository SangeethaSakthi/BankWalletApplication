package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.beans.Transaction;
import com.cg.beans.WalletHolder;
import com.cg.exception.WalletException;

public interface IWalletService {

	int addWallet(WalletHolder holder);

	boolean nameExists(String name)throws WalletException;

	boolean validateName(String name);

	boolean validatePassword(String password);

	boolean validateAccNo(String accountNo);

	boolean validateEmail(String email);

	boolean validatePhNo(String phNo);

	int generatePinNo(WalletHolder holder);

	WalletHolder checkLoginDetails(String name, String password)throws WalletException;

	double withdraw(int pinNo, double balance)throws WalletException;

	double deposit(int pinNo, double balance)throws WalletException;
	
	double moneyTransfer(int pinNo, String uname, double balance) throws WalletException;

	List<Transaction> showTransaction(String name)throws WalletException;

	double showBalance()throws WalletException;

}
