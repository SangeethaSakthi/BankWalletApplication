package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.beans.Transaction;
import com.cg.beans.WalletHolder;
import com.cg.dao.IWalletDao;
import com.cg.dao.WalletDao;
import com.cg.exception.WalletException;

public class WalletService implements IWalletService{

	IWalletDao dao;
	
	private static String nameToMatch = "[A-Z]{1}[a-z]{2,30}";
	private static String passwordToMatch = "[A-Za-z0-9]{4,8}";
	private static String phNoToMatch = "[0-9]{10}";
	private static String accountNoToMatch ="[0-9]{6,16}";
	private static String emailToMatch = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w]+(\\.[\\w]+)*(\\.[a-z]{2,})$"; 

	public WalletService() throws WalletException {
		dao = new WalletDao();
	}
	
	public int addWallet(WalletHolder holder) {
		
		return dao.addWallet(holder);
	}

	public boolean nameExists(String name) throws WalletException {
		
		return dao.nameExists(name);
	}

	
	public boolean validateName(String name) {
		if(name.matches(nameToMatch))
			return true;
		else
			return false;
	}

	
	public boolean validatePassword(String password) {
		if(password.matches(passwordToMatch))
			return true;
		else
		return false;
	}

	
	public boolean validateAccNo(String accountNo) {
		if(accountNo.matches(accountNoToMatch))
			return true;
		else
			return false;	}

	
	public boolean validateEmail(String email) {
		if(email.matches(emailToMatch))
			return true;
		else
			return false;	}

	
	public boolean validatePhNo(String phNo) {
		if(phNo.matches(phNoToMatch))
			return true;
		else
			return false;	
		}

	
	public int generatePinNo(WalletHolder holder) {
		return dao.generatePinNo(holder);
	}

	
	public WalletHolder checkLoginDetails(String name, String password) throws WalletException {
		return dao.checkLoginDetails(name,password);
	}

	
	public double withdraw(int pinNo, double balance) throws WalletException {
		return dao.withdraw(pinNo, balance);
	}

	
	public double deposit(int pinNo, double balance) throws WalletException {
		return dao.deposit(pinNo,balance);
	}

	public double moneyTransfer(int pinNo, String uname, double balance) throws WalletException {
		return dao.moneyTransfer(pinNo, uname,balance);
	}

	public List<Transaction> showTransaction(String name) throws WalletException {
		return dao.showTransaction(name);
	}

	@Override
	public double showBalance() throws WalletException {
		return dao.showBalance();
	}

	

}
