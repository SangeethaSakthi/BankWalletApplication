package com.cg.wallet.WalletAppJPA;

import java.util.ArrayList;
import java.util.List;
/**
 * Hello world!
 *
 */
import java.util.Scanner;

import org.omg.PortableInterceptor.HOLDING;

import com.cg.beans.Transaction;
import com.cg.beans.WalletHolder;
import com.cg.exception.WalletException;
import com.cg.service.IWalletService;
import com.cg.service.WalletService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws WalletException
    {
    	System.out.println("+----------------------------+");
    	System.out.println("| Payment Wallet Application |");
    	System.out.println("+----------------------------+");
    	Scanner sc = new Scanner(System.in);
    	IWalletService service = new WalletService();
    	String choice = null;
    	
    	
    	do
    	{
    		
    		System.out.println("\nChoose sign up if you are new to this application else login"
    				+ " \n\t1. Sign up \n\t2. Login \n\t3. Exit");
    		System.out.println("Select your choice : ");
    		int login = sc.nextInt();
    		String password;
    		switch(login)
    		{
    		case 1://sign up
    			WalletHolder holder = new WalletHolder();
    			boolean n=false;
				do{
    				System.out.println("Enter Username : "); // Username
    				String name = sc.next();
    				if(service.nameExists(name))
    				{
    					System.out.println("Username already exist so please enter different Name : ");
    				}
    				else
    				{
    					if(service.validateName(name))
    					{
    						holder.setName(name);
    	    				n = true;
    					}
    					else
    						System.out.println("Please enter valid Username [eg., James] : ");
    				}
    			}while(n==false);
				n=false;
				
				do
    			{
    				System.out.println("Enter Password : "); //password
    				 password = sc.next();
    				if(service.validatePassword(password))
    				{
    					n = true;
    				}
    				else
    					System.out.println("Please enter valid password only letters and digits atleast of length 4, atmost of length 8");
    			}while(n==false);
    			n=false;
    			System.out.println("Enter Confirm Password : ");
    			do
    			{
    			String confirmPassword = sc.next();
    			if(password.equals(confirmPassword))
    			{
    				n=true;
    				holder.setPassword(confirmPassword);
    			}
    			else
    				System.out.println("Password and confirm password are not matched.\nSo enter the confirm password correctly : ");
    			}while(n==false);
    			n=false;
    			
    			do
    			{
    				System.out.println("Enter account number :");
    				String accountNo = sc.next();
    				if(service.validateAccNo(accountNo))
    					{
    					holder.setAccountNo(accountNo);
    					n = true;
    					}
    				else
    					System.out.println("Account Number should have 16 digits : ");
    				
    			}while(n==false);
    			n=false;
    			
    			do
    			{
    				System.out.println("Enter email id : ");
    				String email = sc.next();
    				if(service.validateEmail(email))
    					{
    					holder.setEmail(email);
    					n = true;
    					}
    				else
    					System.out.println("Please enter valid email id : ");
    				
    			}while(n==false);
    			n=false;
    			
    			do
    			{
    				System.out.println("Enter mobile number : ");
    				String phNo = sc.next();
    				if(service.validatePhNo(phNo))
    					{
    					holder.setPhno(phNo);
    					n = true;
    					}
    				else
    					System.out.println("Please enter valid mobile number : ");
    				
    			}while(n==false);
    			n=false;
    			
    			int pinNo = service.generatePinNo(holder);
    	    	int row = service.addWallet(holder);
    	    	if(row>0)
    	    		System.out.println("Your wallet have created successfully and your pin number is "+pinNo);
    	    	else
    	    		System.out.println("Wallet not created");
    			
    			break;
    		
    		case 2:
    			WalletHolder holder2 = new WalletHolder();
    			String name=null;
    			boolean p=false;
				do{
        			System.out.println("Enter Username : ");
        			name = sc.next();
        			
        			System.out.println("Enter Password : ");
        			String password1 = sc.next();
        			
        			holder2 = service.checkLoginDetails(name, password1);
        			if(holder2==null)
        				{
        				System.out.println("Please enter valid username and password ...");
        				}
        			else
    					p=true;
        			}while(p==false);
				String m=null;
				do
				{
					System.out.println("+-----------------+");
    		    	System.out.println("| Wallet Services |");
    		    	System.out.println("+-----------------+");
    				System.out.println("\t1.Withdraw");
    				System.out.println("\t2.Deposit");
    				System.out.println("\t3.Fund Transfer");
    				System.out.println("\t4.Show Transactions");
    				System.out.println("\t5.Show Balance");
    				System.out.println("\t6.Logout");
    				System.out.println("Enter your choice : ");
    		    	int ch1= sc.nextInt();
    		    	boolean d=false;
    		    	switch(ch1)
    		    	{
    		    	case 1:
    		    		do
    		    		{
	    		    		System.out.println("To continue enter your pin no");
							int pinNo1 = sc.nextInt();
							System.out.println("Enter the amount to withdraw");
							double balance1 = sc.nextDouble();
							double flag=service.withdraw(pinNo1, balance1);
							if( flag>0)
							{
								System.out.println("Withdrawn successfully and your current balance is "+flag);
								d=true;
							}
							else
								System.out.println("Please enter valid pin number and amount");
    		    		}while(d==false);
    		    		d=false;
    		    		break;
    		    	case 2:
    		    		do
    		    		{
	    		    		System.out.println("To continue enter your pin no");
							int pinNo2 = sc.nextInt();
							System.out.println("Enter the amount to deposit");
							double balance2 = sc.nextDouble();
							double flag1=service.deposit(pinNo2, balance2);
							if(flag1>0)
							{
								System.out.println("Deposited successfully and your current balance is "+flag1);
								d=true;
							}
							else
								System.out.println("Please enter valid pin number and amount");
    		    		}while(d==false);
    		    		d=false;
    		    		break;
    		    	case 3:
    		    		do
    		    		{
	    		    		System.out.println("To continue enter your pin no");
							int pinNo3 = sc.nextInt();
							System.out.println("Enter the username who you want to transfer money");
							String name1 = sc.next();
							System.out.println("Enter the amount to transfer");
							double balance3 = sc.nextDouble();
							double flag1= service.moneyTransfer(pinNo3, name1, balance3);
							if(flag1>0)
							{
								System.out.println("Transferred successfully and your current balance is "+flag1);
								d=true;
							}
							else if(flag1<0)
								System.out.println("Please enter valid username");
							else
								System.out.println("Please enter valid pin number and amount");
							
    		    		}while(d==false);
    		    		d=true;
    		    		break;
    		    	case 4:
    		    		System.out.println("Transactions");
    		    		List<Transaction> trans= service.showTransaction(name);
    		    		System.out.println("|   Name    |    AccountNo   |"
    		    				+ "        Description        |  TransactionName  | Deposit | Withdrawal |");
    		    		for(Transaction t:trans)
    		    		System.out.println(t);
    		    		break;
    		    	case 5:
    		    		System.out.println("Your current balance is : "+service.showBalance());
    		    	case 6:
    		    		System.out.println("Thank you!...");
    	    			System.exit(0);
    	    			break;
    	    		
    		    	default :
    		    		System.out.println("Enter valid choice");
    		    		break;
    		    		
    		    	}
    		    	System.out.println("Do you want to continue ? \n=> Enter Yes to continue \n=> Enter No to exit : ");
    		    	m=sc.next();
					
				}while(m.equalsIgnoreCase("yes"));
				
    			break;
    		
    		case 3:
    			System.out.println("Thank you!...");
    			System.exit(0);
    			break;
    		
    		default:
    			System.out.println("Enter valid choice");
    			break;
    			
    		}
    		
    		System.out.println("Do you want to continue ? \n=> Enter Yes to continue \n=> Enter No to exit : ");
			choice = sc.next();
    		
    	}while(choice.equalsIgnoreCase("yes"));
    	
    	
    	
    	
    	
    }
}
